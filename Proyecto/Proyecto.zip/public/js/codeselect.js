function seleccionado() {
    var opt = $("#opcion").val();
    // alert(opt);
    if (opt == "1" || opt == "2") {
        $("#categoria").show();
    }
}
function showContent() {
    element = document.getElementById("content");
    check = document.getElementById("check");
    if (check.checked) {
        element.style.display = "block";
    } else {
        element.style.display = "none";
    }
}
function showContent2() {
    element = document.getElementById("content2");
    check = document.getElementById("check2");
    if (check.checked) {
        element.style.display = "block";
    } else {
        element.style.display = "none";
    }
}
function showContent3() {
    element = document.getElementById("content3");
    check = document.getElementById("check3");
    if (check.checked) {
        element.style.display = "block";
    } else {
        element.style.display = "none";
    }
}
function showContent4() {
    element = document.getElementById("content4");
    check = document.getElementById("check4");
    if (check.checked) {
        element.style.display = "block";
    } else {
        element.style.display = "none";
    }
}
function showContent5() {
    element = document.getElementById("content5");
    check = document.getElementById("check5");
    if (check.checked) {
        element.style.display = "block";
    } else {
        element.style.display = "none";
    }
}
function showContent6() {
    element = document.getElementById("content6");
    check = document.getElementById("check6");
    if (check.checked) {
        element.style.display = "block";
    } else {
        element.style.display = "none";
    }
}
